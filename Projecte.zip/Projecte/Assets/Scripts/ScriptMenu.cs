using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ScriptMenu : MonoBehaviour
{

    public GameObject level1Slider;
    public GameObject level1SliderText;

    public GameObject level2Slider;
    public GameObject level2SliderText;

    public GameObject rex;
    public GameObject mario;
    public GameObject mogus;

    public GameObject selectedText;
    public GameObject coinText;

    public GlobalHolder globalHolder;

    private int selectedModel = 0;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void Salir() {
        Application.Quit();
    }

    private void Start() {
        level2SliderText.GetComponent<TextMeshProUGUI>().text = GlobalHolder.percentageDone2.ToString("P") + " completed";
        level1SliderText.GetComponent<TextMeshProUGUI>().text = GlobalHolder.percentageDone1.ToString("P") + " completed";

        level2Slider.GetComponent<Slider>().value = GlobalHolder.percentageDone2;
        level1Slider.GetComponent<Slider>().value = GlobalHolder.percentageDone1;

        coinText.GetComponent<TextMeshProUGUI>().text = GlobalHolder.coinNum.ToString("D4");

        selectedModel = GlobalHolder.selectedModel;

        selectedText.SetActive(true);

        if (selectedModel == 0) rex.SetActive(true);
        else if (selectedModel == 1) mario.SetActive(true);
        else mogus.SetActive(true);


    }

    // Update is called once per frame
    void Update() {
        
    }

    public void SelectCharacter() {
        selectedText.SetActive(true);
        globalHolder.SelectModel(selectedModel);
    }


    public void ChangeModelAdd() {

        selectedModel = (selectedModel + 1) % 3;

        if (selectedModel == GlobalHolder.selectedModel) {
            selectedText.SetActive(true);
        }
        else selectedText.SetActive(false);

        if (selectedModel == 0) {
            mogus.SetActive(false);
            rex.SetActive(true);
        }

        else if (selectedModel == 1) {
            rex.SetActive(false);
            mario.SetActive(true);
        }

        else {
            mario.SetActive(false);
            mogus.SetActive(true);
        }

    }

    public void ChangeModelDecrease() {

        selectedModel = (selectedModel - 1);

        if (selectedModel == GlobalHolder.selectedModel) {
            selectedText.SetActive(true);
        }
        else selectedText.SetActive(false);

        if (selectedModel < 0) selectedModel = 2;

        if (selectedModel == 0) {
            mario.SetActive(false);
            rex.SetActive(true);
        }

        else if (selectedModel == 1) {
            mogus.SetActive(false);
            mario.SetActive(true);
        }

        else {
            rex.SetActive(false);
            mogus.SetActive(true);
        }

    }


}
