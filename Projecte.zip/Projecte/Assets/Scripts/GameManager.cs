using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using JetBrains.Annotations;
using TMPro;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using static UnityEngine.EventSystems.EventTrigger;

public class GameManager : MonoBehaviour
{

    private GameObject recta;

    private GameObject curve;

    private GameObject cross;

    private GameObject column;

    public GameObject spike;

    public GameObject bullet;

    public GameObject coin;

    public GameObject flower;

    public GameObject bananas;

    public GameObject bomb;

    public GameObject map;

    private Player player;

    public GameObject pauseMenu;

    public GameObject deathMenu;

    public SoundManager soundManager;

    public GameObject coinText;

    public GameObject progressBar;

    public GameObject progressBarText;

    public GameObject levelPassedMenu;

    public GameObject GameUI;

    public GameObject castleBackground;

    public GameObject rainbowBackground;

    public GameObject tutorialPane;

    private int coinNum;

    const float HEIGHT_OFFSET = -1.5f;
    const float COLUMN_INCREASE = 0.25f;

    int shift_left = 0;
    int middle = 0;
    int subLevel = 3;
    int level;

    private int blocksLeft = 0;
    private List<Animator> blockAnimators = new List<Animator>();
    private List<Animator> obstaclesAnimators = new List<Animator>();

    private int previousHeight = 1;
    private bool previousObstacle = false;
    private int currentBlock = 0;

    float currentDone = 0.0f;

    enum Direction { FORWARD, LEFT, RIGHT, BACKWARDS };
    enum FloorType {STRAIGHT, CURVE, X, BOMB, FLOWER, BANANAS, BULLET, COIN};

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start() {

        //
        level = GlobalHolder.level;

        progressBar.GetComponent<Slider>().value = currentDone;
        progressBarText.GetComponent<TextMeshProUGUI>().text = currentDone.ToString("P") + " completed";

        if (level == 1) {
            recta = Resources.Load<GameObject>("Prefabs/Level 1/recte");
            curve = Resources.Load<GameObject>("Prefabs/Level 1/curva");
            cross = Resources.Load<GameObject>("Prefabs/Level 1/X");
            column = Resources.Load<GameObject>("Prefabs/Level 1/columna");
            spike = Resources.Load<GameObject>("Prefabs/Obstacles/pinxos");
            soundManager.ChangeEnvironmentSound("castillo");
            castleBackground.SetActive(true);
        }

        else {
            recta = Resources.Load<GameObject>("Prefabs/Level 2/recte");
            curve = Resources.Load<GameObject>("Prefabs/Level 2/curva");
            cross = Resources.Load<GameObject>("Prefabs/Level 2/X");
            column = Resources.Load<GameObject>("Prefabs/Level 2/columna");
            spike = Resources.Load<GameObject>("Prefabs/Obstacles/laser");
            soundManager.ChangeEnvironmentSound("arcoiris");
            rainbowBackground.SetActive(true);
            tutorialPane.SetActive(false);
        }

        ResetLevel();


    }

    public void getCoin() {
        GlobalHolder.coinNum++;
        PlayCoin();
        loadCoins();
    }

    void loadCoins() {
        coinText.GetComponent<TextMeshProUGUI>().text = GlobalHolder.coinNum.ToString("D4");
    }

    void Update() {

        if (Input.GetKeyDown(KeyCode.Escape)) {

            pauseMenu.SetActive(!pauseMenu.activeInHierarchy);

            if (pauseMenu.activeInHierarchy) {
                player.Pause();
            }

            else {
                player.UnPause();
            }
        
        }

        else if (Input.GetKeyDown(KeyCode.Alpha1)) {
            level = 1;
            currentDone = 0.0f;
            coinNum = 0;
            player.DevDeath();
            recta = Resources.Load<GameObject>("Prefabs/Level 1/recte");
            curve = Resources.Load<GameObject>("Prefabs/Level 1/curva");
            cross = Resources.Load<GameObject>("Prefabs/Level 1/X");
            column = Resources.Load<GameObject>("Prefabs/Level 1/columna");
            spike = Resources.Load<GameObject>("Prefabs/Obstacles/pinxos");
            castleBackground.SetActive(true);
            rainbowBackground.SetActive(false);
            ResetLevel();
        }

        else if (Input.GetKeyDown(KeyCode.Alpha2)) {
            level = 2;
            currentDone = 0.0f;
            coinNum = 0;
            player.DevDeath();
            recta = Resources.Load<GameObject>("Prefabs/Level 2/recte");
            curve = Resources.Load<GameObject>("Prefabs/Level 2/curva");
            cross = Resources.Load<GameObject>("Prefabs/Level 2/X");
            column = Resources.Load<GameObject>("Prefabs/Level 2/columna");
            spike = Resources.Load<GameObject>("Prefabs/Obstacles/laser");
            castleBackground.SetActive(false);
            rainbowBackground.SetActive(true);
            tutorialPane.SetActive(false);
            ResetLevel();
        }

    }

    public void ContinueGame() {
        player.UnPause();
        pauseMenu.SetActive(false);
    }

    void loadMap() {

        int[,] mapa = readMap(subLevel.ToString(), 15);

        int rows = mapa.GetLength(0);
        shift_left = 1;
        int columns = mapa.GetLength(1);

        int i = rows / 2;
        middle = rows / 2;
        int j = 0;
        Direction dir = Direction.FORWARD;
        bool ending = false;

        while (!ending)
        {

            FloorType type = (FloorType)(mapa[i, j] % 8);

            int nextHeight = mapa[i, j] / 8 + 1;

            bool obstacle = false;

            switch (type)
            {
                case FloorType.STRAIGHT:
                    createFloor(recta, i, j, nextHeight, dir);
                    break;

                case FloorType.CURVE:
                    Direction curveTo = checkCurveDirection(mapa, i, j, dir);
                    createCurve(curve, i, j, nextHeight, dir, curveTo);
                    dir = curveTo;
                    break;

                case FloorType.X:
                    createFloor(cross, i, j, nextHeight, dir);
                    break;

                case FloorType.BOMB:
                    createFloor(recta, i, j, nextHeight, dir);
                    createBomb(i, j, nextHeight, dir);
                    obstacle = true;
                    break;

                case FloorType.FLOWER:
                    createFloor(recta, i, j, nextHeight, dir);
                    createFlower(i, j, nextHeight, dir);
                    obstacle = true;
                    break;

                case FloorType.BANANAS:
                    createFloor(recta, i, j, nextHeight, dir);
                    createBananas(i, j, nextHeight, dir);
                    obstacle = true;
                    break;

                case FloorType.BULLET:
                    createFloor(recta, i, j, nextHeight, dir);
                    createBullet(i, j, nextHeight, dir);
                    obstacle = true;
                    break;

                case FloorType.COIN:
                    createFloor(recta, i, j, nextHeight, dir);
                    createCoin(i, j, nextHeight, dir);
                    break;
            }

            if (nextHeight > previousHeight && !previousObstacle) {
                if (level == 1) createWallSpike(i, j, nextHeight, dir);
                else createWallLaser(i, j, nextHeight, dir);
            }

            previousHeight = nextHeight;

            previousObstacle = obstacle;

            createColumn(i, j, nextHeight);

            float random = UnityEngine.Random.Range(0, 11) * 0.1f;

            blocksLeft += 2;

            Invoke("initAnimation", random);

            if (dir == Direction.FORWARD) j++;
            else if (dir == Direction.BACKWARDS) j--;
            else if (dir == Direction.LEFT) i--;
            else i++;

            if (i > rows - 1 || i < 0 || j > columns - 1 || j < 0)
            {
                ending = true;
            }

        }
    }

    private void createCoin(int i, int j, int height, Direction dir) {
        int rotation = 90;
        Vector3 position = new Vector3(j, 0.77f + (height - 1), (middle - i) * shift_left - 0.07f);

        if (dir == Direction.BACKWARDS || dir == Direction.FORWARD) {
            rotation = 0;
            position = new Vector3(j - 0.07f, 0.77f + (height - 1), (middle - i) * shift_left);
        }

        GameObject floor = Instantiate(coin, position, Quaternion.identity);
        floor.transform.Rotate(0, rotation, 0);
        floor.transform.parent = map.transform;
        Animator animator = floor.GetComponent<Animator>();
        obstaclesAnimators.Add(animator);
    }

    private void createBullet(int i, int j, int height, Direction dir) {
        int rotation = 0;
        float shift = -0.4f;
        Vector3 position;

        if (dir == Direction.FORWARD) {
            rotation = 180;
            shift = -shift;
            position = new Vector3(j + shift, 0.87f + (height - 1), (middle - i) * shift_left);
        }
        else if (dir == Direction.LEFT) {
            rotation = 90;
            shift = -shift;
            position = new Vector3(j, 0.87f + (height - 1), (middle - i) * shift_left + shift);
        }
        else if (dir == Direction.RIGHT) {
            rotation = 270;
            position = new Vector3(j, 0.87f + (height - 1), (middle - i) * shift_left + shift);
        }
        else {
            position = new Vector3(j + shift, 0.87f + (height - 1), (middle - i) * shift_left);
        }

        GameObject enemy = Instantiate(bullet, position, Quaternion.identity);
        enemy.transform.Rotate(0, rotation, 270);
        enemy.transform.parent = map.transform;
        Animator animator = enemy.GetComponent<Animator>();
        obstaclesAnimators.Add(animator);
    }

    private void createBananas(int i, int j, int height, Direction dir) {
        int rotation = 90;
        Vector3 position = new Vector3(j, 0.51f + (height - 1), (middle - i) * shift_left - 0.05f);

        if (dir == Direction.BACKWARDS || dir == Direction.FORWARD) {
            rotation = 0;
            position = new Vector3(j - 0.05f, 0.51f + (height - 1), (middle - i) * shift_left);
        }

        GameObject floor = Instantiate(bananas, position, Quaternion.identity);
        floor.transform.Rotate(0, rotation, 0);
        floor.transform.parent = map.transform;
        Animator animator = floor.GetComponent<Animator>();
        obstaclesAnimators.Add(animator);
    }

    private void createFlower(int i, int j, int height, Direction dir) {

        int rotation = 90;
        Vector3 position = new Vector3(j+0.2f, -0.099f + (height - 1), (middle - i) * shift_left);

        if (dir == Direction.BACKWARDS || dir == Direction.FORWARD) {
            rotation = 0;
            position = new Vector3(j, -0.099f + (height - 1), (middle - i) * shift_left + 0.2f);
        }

        GameObject floor = Instantiate(flower, position, Quaternion.identity);
        floor.transform.Rotate(0, rotation, 0);
        floor.transform.parent = map.transform;
        Animator animator = floor.GetComponent<Animator>();
        obstaclesAnimators.Add(animator);

    }

    private void createBomb(int i, int j, int height, Direction dir) {
        int rotation = 90;
        float shift = 0.13f;
        Vector3 position;

        if (dir == Direction.FORWARD) {
            rotation = 270;
            shift = -shift;
            position = new Vector3(j - shift, 0.5f + (height - 1), (middle - i) * shift_left + shift);
        }
        else if (dir == Direction.LEFT) {
            rotation = 180;
            position = new Vector3(j + shift, 0.5f + (height - 1), (middle - i) * shift_left + shift);
        }
        else if (dir == Direction.RIGHT) {
            rotation = 0;
            shift = -shift;
            position = new Vector3(j + shift, 0.5f + (height - 1), (middle - i) * shift_left + shift);
        }
        else {
            position = new Vector3(j - shift, 0.5f + (height - 1), (middle - i) * shift_left + shift);
        }

        GameObject enemy = Instantiate(bomb, position, Quaternion.identity);
        enemy.transform.Rotate(0, rotation, 0);
        enemy.transform.parent = map.transform;
        Animator animator = enemy.GetComponent<Animator>();
        obstaclesAnimators.Add(animator);
    }

    private void createWallSpike(int i, int j, int height, Direction dir) {

        int rotation = 0;
        float shift = 0.5f;
        Vector3 position;

        if (dir == Direction.FORWARD) {
            rotation = 180;
            shift = -0.5f;
            position = new Vector3(j + shift, 0.024f + (height - 1), (middle - i) * shift_left);
        }
        else if (dir == Direction.LEFT) {
            rotation = 90;
            shift = -0.5f;
            position = new Vector3(j, 0.024f + (height - 1), (middle - i) * shift_left + shift);
        }
        else if (dir == Direction.RIGHT) {
            rotation = 270;
            position = new Vector3(j, 0.024f + (height - 1), (middle - i) * shift_left + shift);
        }
        else {
            position = new Vector3(j + shift, 0.024f + (height - 1), (middle - i) * shift_left);
        }

        GameObject enemy = Instantiate(spike, position, Quaternion.identity);
        enemy.transform.Rotate(0, rotation, -90);
        enemy.transform.parent = map.transform;
        Animator animator = enemy.GetComponent<Animator>();
        obstaclesAnimators.Add(animator);
    }

    private void createWallLaser(int i, int j, int height, Direction dir) {
        int rotation = 0;
        float shift = 1f;
        Vector3 position;

        if (dir == Direction.FORWARD) {
            rotation = 180;
            shift = -shift;
            position = new Vector3(j + shift, -0.506f + (height - 1), (middle - i) * shift_left);
        }
        else if (dir == Direction.LEFT) {
            rotation = 90;
            shift = -shift;
            position = new Vector3(j, -0.506f + (height - 1), (middle - i) * shift_left + shift);
        }
        else if (dir == Direction.RIGHT) {
            rotation = 270;
            position = new Vector3(j, -0.506f + (height - 1), (middle - i) * shift_left + shift);
        }
        else {
            position = new Vector3(j + shift, -0.506f + (height - 1), (middle - i) * shift_left);
        }

        GameObject enemy = Instantiate(spike, position, Quaternion.identity);
        enemy.transform.Rotate(0, rotation, 0);
        enemy.transform.parent = map.transform;
        Animator animator = enemy.GetComponent<Animator>();
        obstaclesAnimators.Add(animator);
    }
    void initAnimation() {

        if (currentBlock < blocksLeft) {
            Animator animator = blockAnimators.ElementAt(currentBlock);
            animator.enabled = true;
            currentBlock++;
            animator = blockAnimators.ElementAt(currentBlock);
            animator.enabled = true;
            currentBlock++;
        }

        if (currentBlock >= blocksLeft) {

            Invoke("endAnimation", 1.3f);
            
        }
    }

    void endAnimation() {

        foreach (Animator animator in obstaclesAnimators) {
            animator.enabled = true;
        }

        player.ReadyRunning();
    }

    void createColumn(int i, int j, int height) {

        GameObject new_column = Instantiate(column, new Vector3(j, -31.5f - 6.75f*(height-1), (middle - i) * shift_left), Quaternion.identity);
        new_column.transform.localScale += new Vector3(0, (height - 1) * COLUMN_INCREASE, 0);
        new_column.transform.parent = map.transform;
        Animator animator = new_column.GetComponent<Animator>();
        blockAnimators.Add(animator);

    }

    void createCurve(GameObject model, int i, int j, int height, Direction from, Direction to) {
        int angle = 0;
        string tag = "LEFT";

        if (from == Direction.FORWARD) {
            if (to == Direction.RIGHT) {
                angle = 90;
                tag = "RIGHT";
            }
            if (to == Direction.LEFT) {
                angle = 180;
            }
        }

        else if (from == Direction.BACKWARDS) {
            if (to == Direction.LEFT) {
                angle = 270;
                tag = "RIGHT";
            }
        }

        else if (from == Direction.LEFT) {

            if (to == Direction.BACKWARDS) angle = 90;
            else tag = "RIGHT";

        }

        else {

            if (to == Direction.FORWARD) angle = 270;
            else {
                tag = "RIGHT";
                angle = 180;

            }

        }

        Vector3 scale = new Vector3(0.25f, 0.5f, 0.25f);

        GameObject floor = Instantiate(model, new Vector3(j, -15 + (height-1), (middle-i)*shift_left), Quaternion.identity);
        floor.transform.Rotate(0, angle, 0);
        floor.transform.localScale = scale;
        floor.transform.GetChild(0).tag = tag;
        floor.transform.SetParent(map.transform);
        Animator animator = floor.GetComponent<Animator>();
        blockAnimators.Add(animator);

    }

    Direction checkCurveDirection(int[,] mapa, int i, int j, Direction from) {


        if (from == Direction.RIGHT || from == Direction.LEFT)
        {
            if (j - 1 > 0 && mapa[i, j-1] > -1) return Direction.BACKWARDS;
            else return Direction.FORWARD;
        }

        if (i - 1 > 0 && mapa[i -1, j] > -1) return Direction.LEFT;
        else return Direction.RIGHT;
    }

    void createFloor(GameObject model, int i, int j, int height, Direction dir) {

        int rotation = 0;

        if (dir == Direction.BACKWARDS || dir == Direction.FORWARD) rotation = 90;

        GameObject floor = Instantiate(model, new Vector3(j, -15f + (height-1), (middle-i)*shift_left), Quaternion.identity);
        floor.transform.Rotate(0, rotation, 0);
        floor.transform.parent = map.transform;
        Animator animator = floor.GetComponent<Animator>();
        blockAnimators.Add(animator);
    }

    int [,] readMap(string subLevel, int sizeY) {

        TextAsset mapCSV = Resources.Load<TextAsset>("Maps/Level " + level.ToString() + "/" + subLevel);


        string[] data = mapCSV.text.Split(new String[] { ",", "\n" }, StringSplitOptions.None);

        int sizeX = data.Length / sizeY;



        int[,] map = new int[sizeY, sizeX];

        for (int i = 0; i < sizeY; i++) {
            for (int j = 0; j < sizeX; j++) {
                map[i, j] = int.Parse(data[sizeX * i + j]); 

            }

        }

        return map;


    }

    public void DestroyObstaclesLoad() {
        foreach (Animator animator in obstaclesAnimators) {
            animator.Play("Dissapear");
        }
        Invoke("DestroyBlocksLoad", 0.5f);
    }

    void DestroyBlocksLoad() {
        foreach (Animator animator in blockAnimators) {
            animator.Play("Dissapear");
        }
        Invoke("changeMap", 1.2f);
    }

    public void changeMap() {

        if (level == 1 && subLevel == 1) {
            tutorialPane.GetComponent<Animator>().Play("DissapearTutorial");
            Invoke("disableTutorial", 1f);
        }

        Destroy(map);
        blocksLeft = 0;
        currentBlock = 0;
        blockAnimators = new List<Animator>();
        obstaclesAnimators = new List<Animator>();
        map = Instantiate(new GameObject(), Vector3.zero, Quaternion.identity);
        map.name = "Map";
        subLevel++;
        currentDone = (subLevel-1) / 10.0f;

        if (level == 1 && currentDone > GlobalHolder.percentageDone1) GlobalHolder.percentageDone1 = currentDone;
        else if (level == 2 && currentDone > GlobalHolder.percentageDone2) GlobalHolder.percentageDone2 = currentDone;

        progressBar.GetComponent<Slider>().value = currentDone;
        progressBarText.GetComponent<TextMeshProUGUI>().text = currentDone.ToString("P") + " completed";

        if (subLevel > 10) {
            levelPassedMenu.SetActive(true);
            GameUI.SetActive(false);
        }

        else {
            loadMap();
            if (level == 1 && subLevel == 1) {
                tutorialPane.SetActive(true);
                tutorialPane.GetComponent<Animator>().enabled = true;
            }
        }


    }

    void disableTutorial() {
        tutorialPane.GetComponent<Animator>().enabled = false;
        tutorialPane.SetActive(false);
    }

    public void NextLevel() {
        if (level == 1) {

            level = 2;
            currentDone = 0.0f;
            player.DevDeath();
            recta = Resources.Load<GameObject>("Prefabs/Level 2/recte");
            curve = Resources.Load<GameObject>("Prefabs/Level 2/curva");
            cross = Resources.Load<GameObject>("Prefabs/Level 2/X");
            column = Resources.Load<GameObject>("Prefabs/Level 2/columna");
            spike = Resources.Load<GameObject>("Prefabs/Obstacles/laser");
            ResetLevel();
            levelPassedMenu.SetActive(false);
            GameUI.SetActive(true);
            castleBackground.SetActive(false);
            rainbowBackground.SetActive(true);
        }


    }

    public void PlayJump() {
        soundManager.PlayPlayerSound("salto");
    }

    public void PlayDead()
    {
        soundManager.PlayDeathSound();
    }
    public void PlayCoin()
    {
        soundManager.PlayPlayerSound("moneda");
    }
    public void PlayBom()
    {
        soundManager.PlayPlayerSound("bomba");
    }

    public void GoToMenu() {
        SceneManager.LoadScene(0);
    }

    public void ResetLevel() {
        disableTutorial();
        subLevel = 0;
        GameObject currentPlayer = Instantiate(GlobalHolder.player);
        player = currentPlayer.GetComponent<Player>();
        loadCoins();

        if (level == 1) {
            soundManager.ChangeEnvironmentSound("castillo");
        }

        else {
            soundManager.ChangeEnvironmentSound("arcoiris");
        }

        changeMap();
    }

    public void PlayerDeath() {
        PlayDead();
        deathMenu.SetActive(true);
    }

}
