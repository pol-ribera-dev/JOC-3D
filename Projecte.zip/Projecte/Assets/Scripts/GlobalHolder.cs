using UnityEngine;
using UnityEngine.SceneManagement;

public class GlobalHolder : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public static int selectedLevel;
    public static float currentVolume = 1.0f;
    public static int level = 1;
    public static float percentageDone1 = 0.0f;
    public static float percentageDone2 = 0.0f;
    public static GameObject player;
    public static int selectedModel;
    public static int coinNum = 0;

    private void Awake() {
        if (player == null) {
            player = Resources.Load<GameObject>("Prefabs/Players/animados/T-Rex");
            selectedModel = 0;
        }
    }

    public void SelectModel(int selected) {

        selectedModel = selected;

        if (selectedModel == 0) {

            player = Resources.Load<GameObject>("Prefabs/Players/animados/T-Rex");

        }

        else if (selectedModel == 1) {

            player = Resources.Load<GameObject>("Prefabs/Players/animados/mario");

        }

        else {

            player = Resources.Load<GameObject>("Prefabs/Players/animados/mungus");

        }

    }

    public void changeVolume(float value) {
        currentVolume = value;
    }

    public void playLevel1() {
        level = 1;
        SceneManager.LoadScene(1);
    }

    public void playLevel2() { 
        level = 2;
        SceneManager.LoadScene(1);
    }

}
