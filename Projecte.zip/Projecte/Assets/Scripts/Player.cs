using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.XR;
using UnityEngine.UIElements;

public class Player : MonoBehaviour
{

    enum Direction {FORWARD, LEFT, RIGHT, BACKWARDS};


    private CharacterController controller;
    private float y_velocity;
    public int maxVelocity; //In number of tiles per second
    private string newDir;
    private bool stoped = false;
    private GameManager gameManager;
    public float gravityValue;
    public float jumpForce;
    private Vector3 moveDirection;
    public Animator animator;
    private ParticleSystem particulas;
    private Animator animator2;
    private bool GodMode = false;
    private bool godJump = false;
    private Vector3 turnCenter;
    public ParticleSystem deathParticles;
    private float rotation = 90;
    private Direction characterDirection = Direction.FORWARD;
    private bool pause = false;
    private bool delay = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start() {
        controller = GetComponent<CharacterController>();
        y_velocity = gravityValue * gravityValue * -1;
        moveDirection = transform.TransformDirection(Vector3.right) * 0;
        //deathParticles = GetComponentInChildren<ParticleSystem>();
        deathParticles.Stop();
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();

    }

    public void ReadyRunning() {
        stoped = false;
        Invoke("StartRunning", 0.4f);
    }

    private void StartRunning() {
        moveDirection = transform.TransformDirection(Vector3.right) * maxVelocity;
    }

    private void FixedUpdate() { 

    }

    private bool HasObjectForward() {
        Physics.queriesHitTriggers = true;

        Vector3 rayPos = new Vector3(transform.position.x, 10, transform.position.z);

        if ( characterDirection == Direction.FORWARD) {
            rayPos += new Vector3(1, 0, 0);
        }

        else if (characterDirection == Direction.LEFT) {
            rayPos += new Vector3(0, 0, 1);
        }

        else if (characterDirection == Direction.RIGHT) {
            rayPos += new Vector3(0, 0, -1);
        }

        else {
            rayPos += new Vector3(-1, 0, 0);
        }

        return Physics.Raycast(rayPos, -Vector3.up, 11, LayerMask.GetMask("Enemy"));
    }

    private void Update() {

        if (!stoped && !pause) {
            GodModeCheck();
            MovePlayer();
        }

        if (transform.position.y < -3) {
            Death();
        }

    }

    public void Pause() {
        moveDirection = transform.TransformDirection(Vector3.right) * 0;
        pause = true;
    }

    public void UnPause() {
        moveDirection = transform.TransformDirection(Vector3.right) * maxVelocity;
        pause = false;
    }

    private void GodModeCheck() {

        if (Input.GetKeyDown(KeyCode.G)) {
            GodMode = !GodMode;
        }


        if (GodMode) {
            godJump = (godJump || HasObjectForward()) && !delay;
        }

    }

    private void MovePlayer() {

        y_velocity += gravityValue * gravityValue * -1;

        controller.Move(Time.deltaTime * y_velocity * Vector3.up);

        if (controller.isGrounded) {
            y_velocity = 0;
            if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0) || godJump) {
                godJump = false;
                delay = true;
                Invoke("endDelay", 0.2f);
                Transform localTransform = transform.GetChild(0).gameObject.transform;
                transform.GetChild(0).gameObject.transform.rotation = Quaternion.Euler(0f, rotation, 0f);
                y_velocity = jumpForce;
                animator.SetTrigger("Jump");
                gameManager.PlayJump();
            }
        }

        controller.Move(Time.deltaTime * moveDirection);
    }

    void endDelay() {
        delay = false;
    }

    public void OnTriggerEnter(Collider col) {

        if (col.gameObject.CompareTag("Spike")) {
            Death();
        }

        else if (col.gameObject.CompareTag("Final")) {

            Invoke("stop", (1f / maxVelocity) / 2);

        }

        else if (col.gameObject.CompareTag("Init")) {
            
            stoped = false;

        }

        else if (col.gameObject.CompareTag("Bomb")) {
         
            animator2 = col.gameObject.GetComponent<Animator>();
            animator2.SetTrigger("bum");
            particulas = col.gameObject.GetComponent<ParticleSystem>();
            particulas.Play();
            gameManager.PlayBom();

        }

        else if (col.gameObject.CompareTag("Coin"))
        {
            col.gameObject.SetActive(false);
            gameManager.getCoin();
            
        }

        else {
            newDir = col.gameObject.tag;
            float distance = 0;
            Vector3 collisionPoint = GetComponent<Collider>().ClosestPoint(col.bounds.center);
            Vector3 distances = collisionPoint - GetComponent<Collider>().bounds.center;
            if (distances.x == 0) distance = distances.z;
            else distance = distances.x;
            col.enabled = false;
            turnCenter = col.bounds.center;
            Invoke("changeDirection", distance / maxVelocity);
        }

    }

    private void stop() {

        stoped = true;
        gameManager.DestroyObstaclesLoad();
        transform.position = new Vector3(-1, 1f, 0f);
        moveDirection = transform.TransformDirection(Vector3.right) * 0;

    }

    void changeDirection() {

        int newRotation = 0;

        if (newDir == "RIGHT") {

            newRotation = 90;

            if (characterDirection == Direction.FORWARD) characterDirection = Direction.RIGHT;
            else if (characterDirection == Direction.LEFT) characterDirection = Direction.FORWARD;
            else if (characterDirection == Direction.RIGHT) characterDirection = Direction.BACKWARDS;
            else characterDirection = Direction.LEFT;




        }

        if (newDir == "LEFT") {
            newRotation = -90;

            if (characterDirection == Direction.FORWARD) characterDirection = Direction.LEFT;
            else if (characterDirection == Direction.LEFT) characterDirection = Direction.BACKWARDS;
            else if (characterDirection == Direction.RIGHT) characterDirection = Direction.FORWARD;
            else characterDirection = Direction.RIGHT;


        }


        transform.Rotate(0, newRotation, 0);
        transform.SetPositionAndRotation(new Vector3(turnCenter.x, transform.position.y, turnCenter.z), transform.rotation);
        moveDirection = transform.TransformDirection(Vector3.right) * maxVelocity;
        Physics.SyncTransforms();
        rotation += newRotation;
    }

    void Death() {
        deathParticles.transform.SetParent(null);
        deathParticles.Play();
        gameObject.SetActive(false);
        gameManager.PlayerDeath();
        Destroy(gameObject);
    }

    public void DevDeath() {
        gameObject.SetActive(false);
        Destroy(gameObject);
    }

}
