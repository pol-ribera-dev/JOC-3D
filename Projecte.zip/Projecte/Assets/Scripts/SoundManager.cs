using Unity.VisualScripting;
using UnityEngine;

public class SoundManager : MonoBehaviour {
    // Start is called once before the first execution of Update after the MonoBehaviour is created


    public AudioSource playerAudio;
    public AudioSource environmentAudio;
    public AudioSource effectAudio;

    private void Start() {
        environmentAudio.loop = true;
    }

    public void PlayPlayerSound(string sound) {
        AudioClip audioClip = Resources.Load<AudioClip>("Sounds/Player/" + sound);
        playerAudio.PlayOneShot(audioClip);
    }

    public void ChangeEnvironmentSound(string sound) {
        environmentAudio.loop = true;
        environmentAudio.Stop();
        AudioClip audioClip = Resources.Load<AudioClip>("Sounds/Environment/" + sound);
        environmentAudio.resource = audioClip;
        environmentAudio.Play();

    }

    public void PlayDeathSound() {
        environmentAudio.loop = false;
        environmentAudio.Stop();
        AudioClip audioClip = Resources.Load<AudioClip>("Sounds/Environment/muerte");
        environmentAudio.resource = audioClip;
        environmentAudio.Play();
    }

    public void PlayEffectSound(string sound) {
        AudioClip audioClip = Resources.Load<AudioClip>("Sounds/Effect/" + sound);
        effectAudio.PlayOneShot(audioClip);
    }

}
